package com.wck.zookeeper.server;

import java.io.IOException;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.ZooDefs.Ids;

public class DistributeServer {
	
	
	//ע��zookeeper��������
	public static void main(String[] args) throws Exception {
		DistributeServer server = new DistributeServer();
		//����zookeeper��Ⱥ
		server.getConnect();
		System.out.println("������"+args[0]);
		//ע��
		server.register(args[0]);
		
		//�����߼�ҵ��
		server.business();
	}

	//�����߳�Ϊ���״̬
	private void business() throws InterruptedException {
		Thread.sleep(Long.MAX_VALUE);
	}

	private void register(String hostName) throws KeeperException, InterruptedException {
		System.out.println("�յ�������Ϊ��"+hostName);
		
		String path = zooKeeperClient.create("/servers/server", hostName.getBytes(), Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
		System.out.println(hostName+"�Ѿ������ˣ�pathΪ��"+"/servers/"+hostName);
	}

	private String connectString="192.168.0.106:2181,192.168.0.103:2181,192.168.0.101:2181";
	private int sessionTimeout=2000;
	private ZooKeeper zooKeeperClient;
	//����
	private void getConnect() throws IOException {
	 zooKeeperClient = new ZooKeeper(connectString, sessionTimeout, new Watcher() {
			public void process(WatchedEvent event) {
				System.out.println("��������event.getType()��"+event.getType());
			}
		});
		
	}

}
