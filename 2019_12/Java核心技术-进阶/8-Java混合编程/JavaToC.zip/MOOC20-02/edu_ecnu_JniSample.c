#include "edu_ecnu_JniSample.h"
JNIEXPORT jint JNICALL Java_edu_ecnu_JniSample_sum
   (JNIEnv *env, jobject obj, jint num1, jint num2) {
    return num1 + num2;
 }
 
void main(){}

