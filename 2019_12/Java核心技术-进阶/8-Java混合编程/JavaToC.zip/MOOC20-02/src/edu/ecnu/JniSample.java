package edu.ecnu;

public class JniSample {
	public native int sum(int num1, int num2);

	/**
	 * 1. ��дJava���룬ע��native����
	 * 2. ����ͷ�ļ� javah -cp bin edu.ecnu.JniSample //now get edu_ecnu_JniSample.h file
	 * 3.implements edu_ecnu_JniSample.h using edu_ecnu_JniSample.c
	 * 4.compile edu_ecnu_JniSample.c get dll
	 * 5.run JniSample
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.loadLibrary("JniSample");  //dll����
		JniSample sample = new JniSample();
		int sum = sample.sum(5, 7);
		
		System.out.println("��: " + sum);
	
	}
}
