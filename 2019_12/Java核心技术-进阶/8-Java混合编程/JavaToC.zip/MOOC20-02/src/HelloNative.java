

class HelloNative
{  
   public static native void greeting();
}
