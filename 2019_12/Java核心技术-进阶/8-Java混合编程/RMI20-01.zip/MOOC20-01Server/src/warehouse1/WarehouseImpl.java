package warehouse1;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;


public class WarehouseImpl extends UnicastRemoteObject implements Warehouse
{
   private Map<String, Double> prices;

   public WarehouseImpl() throws RemoteException
   {
	  //��Ʒ�б�
      prices = new HashMap<>();
      prices.put("�����", 24.95);
      prices.put("΢��¯", 49.95);
   }

   public double getPrice(String description) throws RemoteException
   {
      Double price = prices.get(description);
      return price == null ? 0 : price;
   }
}
