package warehouse1;
import java.rmi.*;

/**
 * �ӿ���
 * 
 */
public interface Warehouse extends Remote
{  
   double getPrice(String description) throws RemoteException;
}
