import java.io.File;


public class FileTest {

	public static void main(String[] args) {
		
		System.setProperty("java.security.policy","file:E:/java/source/PMOOC13-07/dist.policy");
		System.setSecurityManager(new SecurityManager());
		
		File f = new File("F:/temp/1.txt");
		if(f.exists()){
			f.delete();
		}
		
	}
}
