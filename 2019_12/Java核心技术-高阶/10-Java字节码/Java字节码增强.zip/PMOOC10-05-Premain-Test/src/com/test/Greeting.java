package com.test;

public class Greeting {
	public void hello() {
		System.out.println("Hello from Java 111111");
	}
}


