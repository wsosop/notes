import com.test.Greeting;

public class Test {

	public static void main(String[] args) {
		Greeting foo = new Greeting();
		foo.hello();

	}

}
