import com.test.Greeting;

public class Test2 {

	public static void main(String[] args) {
		Greeting foo = new Greeting();
		foo.hello();

	}

}
