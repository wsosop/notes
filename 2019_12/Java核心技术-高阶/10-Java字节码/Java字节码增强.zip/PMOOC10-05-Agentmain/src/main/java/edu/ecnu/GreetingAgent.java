package edu.ecnu;


import java.lang.instrument.Instrumentation;



public class GreetingAgent {

	public static void agentmain(String agentArgument, Instrumentation instrumentation) throws Exception {
		System.out.println("Main Agent");
		SimpleClassTransformer sct = new SimpleClassTransformer();
		instrumentation.addTransformer(sct, true); //only true can transform class
		instrumentation.retransformClasses(Class.forName("com.test.Greeting"));		
	}
//	
//	public static void premain(String agentArgument, Instrumentation instrumentation) {
//		SimpleClassTransformer sct = new SimpleClassTransformer();
//		instrumentation.addTransformer(sct);
//		System.out.println("Hello Agent Premain");
//	}
	
	/*
	private static Instrumentation INST;

    public static void agentmain(String agentArgs, Instrumentation inst) {
        INST = inst;
        process();
    }

    private static void process() {
        INST.addTransformer(new ClassFileTransformer() {

            @Override
            public byte[] transform(ClassLoader loader, String className,
                                    Class<?> clazz,
                                    ProtectionDomain protectionDomain,
                                    byte[] byteCode) throws IllegalClassFormatException {
                System.out.println(String.format("Process by ClassFileTransformer,target class = %s", className));
                return byteCode;
            }
        }, true);
        try
        {
        	INST.retransformClasses(Class.forName("Test"));
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    }
    */
}
