import java.util.List;


import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;

public class AttachToTest {

	public static void main(String[] args) throws Exception {
		List<VirtualMachineDescriptor> vmds = VirtualMachine.list();
		
		for(VirtualMachineDescriptor vmd:vmds)
		{
			if(vmd.displayName().equals("Test"))
			{
				VirtualMachine vm = VirtualMachine.attach(vmd.id());
				vm.loadAgent("E:/java/source/PMOOC10-05-Agentmain/target/PMOOC10-05-Agentmain-0.0.1.jar", "argument for agent");
				System.out.println(vmd.displayName() + "load ok");
				vm.detach();				
			}
		}
	}

}
