import com.test.Greeting;

public class Test {

	public static void main(String[] args) throws Exception {
    	Greeting foo = new Greeting();
        for (; ; ) {
            Thread.sleep(2000);
            foo.hello();
        }
    }

}
